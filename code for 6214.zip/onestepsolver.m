function [pi_diff_full, pi_diff_part] = onestepsolver(n, p, m, h, sigma_x, sigma_n)

Pi_orig = (1:1:n).';

Pi_orig(1:h) = 2:(h + 1);
Pi_orig(h + 1) = 1; 

A = normrnd(0, 1, [n, p]); 

X = sigma_x * eye(p, m);   

N = sigma_n * normrnd(0, 1, [n, m]); 

Y = A * X + N; 
Y = Y(Pi_orig, :); 


Pi_fullrecover = permuteproj(Y * (Y.') * A * (A.'));

pi_diff_full = sum(Pi_orig ~= Pi_fullrecover)/n;

Pi_partrecover = greedyselection(Y * (Y.') * A * (A.'));

pi_diff_part = sum(Pi_orig ~= Pi_partrecover)/n;

end

 





