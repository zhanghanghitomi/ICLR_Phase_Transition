function [simul_statis] =  unit_case_simul(simul_param)


for idx = 1: 1: simul_param.max_case
    
       [full_rate, part_rate] = onestepsolver(...
       simul_param.n,...
       simul_param.p,...
       simul_param.m,...
       simul_param.h,...
       simul_param.sigma_x,...
       simul_param.sigma_n); 
   
   
   simul_statis.diff_pi_arr_full(idx) = full_rate; 
   simul_statis.diff_pi_arr_part(idx) = part_rate;
   
end 

simul_statis.ylab_full_type1 = sum(simul_statis.diff_pi_arr_full == 0)/simul_param.max_case; 
simul_statis.ylab_part_type1 = sum(simul_statis.diff_pi_arr_part == 0)/simul_param.max_case;


end
















