close all; 
clear all; 

simul_param.max_case = 100;
simul_param.sigma_n = 1.0;

simul_param.n = 600;
simul_param.p = 200;

simul_param.h = 75; 

x_arr = 0.5:0.5:3.5;

corr_rate_marr_full = zeros(length(x_arr), 1);
corr_rate_marr_part = zeros(length(x_arr), 1);


%% 
simul_param.m = 75;

for x_idx = 1:1:length(x_arr)    
    
    simul_param.sigma_x = x_arr(x_idx); 
    simul_statis = unit_case_simul(simul_param); 
    
    corr_rate_marr_full(x_idx) = simul_statis.ylab_full_type1; 
    corr_rate_marr_part(x_idx) = simul_statis.ylab_part_type1;
    
end
 

figure;
plot(x_arr, corr_rate_marr_full, 'r-x', 'linewidth', 2, 'MarkerSize', 6); hold on; grid on;
plot(x_arr, corr_rate_marr_part, 'k-^', 'linewidth', 2, 'MarkerSize', 6);


set(gca,'FontSize',20);

legend('Full Recovery', 'Partial Recovery', 'Interpreter' , 'latex', 'FontSize', 20);

text(2, 0.4, ['Non-Oracle'],'fontsize', 20, 'fontweight', 'bold', 'color', 'r');	
xlabel('SNR');
ylabel('Recovery Prob.');
 
 
 








