function [pi_out] = permuteproj(pi_in)

%disp('permute proj'); 

[h, w] = size(pi_in);

pi_in = sparse(pi_in - min(pi_in(:)));

weight = sparseAssignmentProblemAuctionAlgorithm(pi_in);

pi_out = weight; 

end