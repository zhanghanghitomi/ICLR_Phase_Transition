function [pi_out] = greedyselection(pi_in)

[h, w] = size(pi_in); 

pi_out = zeros(h, 1); 

for hidx = 1:1:h
    [~, idx_arr] = sort(pi_in(hidx, :), 'descend');
    pi_out(hidx) = idx_arr(1); 
end

end